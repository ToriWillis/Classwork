package willis.classworkapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassworkApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClassworkApiApplication.class, args);
	}

}
